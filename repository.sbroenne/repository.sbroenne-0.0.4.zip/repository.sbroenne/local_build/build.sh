#!/bin/bash
rm -rf ../repository.sbroenne.zíp
7za a -tzip ../repository.sbroenne-0.0.1.zip ../addon.xml

