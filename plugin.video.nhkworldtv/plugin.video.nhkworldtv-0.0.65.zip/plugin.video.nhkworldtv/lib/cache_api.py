# Cache backend (Azure Functions) API

url = {
    'cache_get_program':
    'https://nhkworldtvwe.azurewebsites.net/api/Program/{0}',
    'cache_get_program_list':
    'https://nhkworldtvwe.azurewebsites.net/api/Program/List/{0}'
}

api_key = "7KMAEaTfS3iCLFzRtKjpqsUWC8y8wZb3sTFU3m9nrjHCwgjKEMUyKw=="
