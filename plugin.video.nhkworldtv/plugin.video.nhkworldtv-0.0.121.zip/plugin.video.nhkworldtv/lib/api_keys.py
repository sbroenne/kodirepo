# -*- coding: utf-8 -*-
from __future__ import (unicode_literals)
# NHK
NHK_API_KEY = 'EJfK8jdS57GqlupFgAfAAwr573q01y6k'
NHK_API_BASE_URL = 'https://api.nhk.or.jp/nhkworld/'
NHK_BASE_URL = 'https://www3.nhk.or.jp'

# Azure Cache
CACHE_API_BASE_URL = 'https://nhkworldtvwe.azurewebsites.net/api'
CACHE_API_KEY = '7KMAEaTfS3iCLFzRtKjpqsUWC8y8wZb3sTFU3m9nrjHCwgjKEMUyKw=='
