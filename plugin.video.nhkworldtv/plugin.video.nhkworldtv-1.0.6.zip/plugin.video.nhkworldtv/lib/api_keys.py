"""
NHK API Key Definition
"""

# NHK
NHK_API_KEY = "EJfK8jdS57GqlupFgAfAAwr573q01y6k"
NHK_API_BASE_URL = "https://api.nhk.or.jp/nhkworld/"
NHK_BASE_URL = "https://www3.nhk.or.jp"
